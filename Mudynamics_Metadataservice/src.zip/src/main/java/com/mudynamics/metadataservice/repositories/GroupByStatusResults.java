package com.mudynamics.metadataservice.repositories;

public interface GroupByStatusResults {

	 String getStatus();
	long getCount();
	
	
}
