package com.mudynamics.workflowservice.models;

public class ClaimedTaskCount 
{ 
	private long count;
    public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	
} 
