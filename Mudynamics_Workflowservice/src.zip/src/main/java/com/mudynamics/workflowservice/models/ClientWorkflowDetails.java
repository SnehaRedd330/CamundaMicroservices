package com.mudynamics.workflowservice.models;





public class ClientWorkflowDetails {
	private String deploymentName;
	private String xmldata;
	public String getDeploymentName() {
		return deploymentName;
	}
	public void setDeploymentName(String deploymentName) {
		this.deploymentName = deploymentName;
	}
	public String getXmldata() {
		return xmldata;
	}
	public void setXmldata(String xmldata) {
		this.xmldata = xmldata;
	}
	
	
}
