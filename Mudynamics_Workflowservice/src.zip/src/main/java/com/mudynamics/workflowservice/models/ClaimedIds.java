package com.mudynamics.workflowservice.models;

public class ClaimedIds 
{
   private String processInstanceId;

public String getProcessInstanceId() {
	return processInstanceId;
}

 public void setProcessInstanceId(String processInstanceId) {
	this.processInstanceId = processInstanceId;
 }
}
