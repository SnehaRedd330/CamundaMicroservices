package com.mudynamics.mudynamicsloginservice.config;

public final class Constants {

	private Constants(){}
	
	 public  static final String TIME_FORMATTER = "dd-MM-yy hh.mm aa";
	 
	 
	 }
