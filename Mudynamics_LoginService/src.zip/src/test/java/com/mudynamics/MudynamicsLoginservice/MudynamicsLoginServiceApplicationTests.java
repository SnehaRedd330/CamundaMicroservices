package com.mudynamics.MudynamicsLoginservice;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MudynamicsLoginServiceApplicationTests {

	@Test
	public void contextLoads() {
	}

}

